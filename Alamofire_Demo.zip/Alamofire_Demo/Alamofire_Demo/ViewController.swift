//
//  ViewController.swift
//  Alamofire_Demo
//
//  Created by 李娜 on 2019/2/27.
//  Copyright © 2019 李娜. All rights reserved.
//

import UIKit
import NetworkExtension
import Alamofire
import AlamofireObjectMapper

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        NetWorkRequest.sharedInstance.getRequest(UrlString:BaseUrl, params:nil, success: { (response) in
            print(response)
        }) { (error) in
            
            }
     self.webRequst()
        
    }
   
  
    func webRequst()  {
        let url = "https://httpbin.org/get"
        //注意返回的类型为<Mappable对象,NSError>
        Alamofire.request(url).responseObject {
            (response: DataResponse <MyResponse>) in
            let myResponse = response.result.value
           // print(myResponse?.url)
            if let header = myResponse?.headers{
             //   print(header.userAgent)
        }
    }
}
}
