//
//  ResponseHeader.swift
//  Alamofire_Demo
//
//  Created by 李娜 on 2019/2/27.
//  Copyright © 2019 李娜. All rights reserved.
//被映射的类

import UIKit
import ObjectMapper

class ResponseHeader: Mappable {
    var accept : String?
    var acceptEncoding : String?
    var acceptLanguage : String?
    var cacheControl : String?
    var host : String?
    var userAgent : String?
    
    required init?(map: Map) {
        
    }
    
    //映射heades字典中的所有键值
    func mapping(map: Map) {
        accept <- map["Accept"]
        acceptEncoding <- map["Accept-Encoding"]
        acceptLanguage <- map["Accept-Language"]
        cacheControl <- map["Cache-Control"]
        host <- map["Host"]
        userAgent <- map["User-Agent"]
    }
   
}
