//
//  CryptTools.swift
//  CryptoSwift_Demo
//
//  Created by 李娜 on 2019/2/28.
//  Copyright © 2019 李娜. All rights reserved.
//

import UIKit
import CryptoSwift

class CryptTools: NSObject {
    
    //encode strToEncode传原始字符串 key密钥字符串
    public static func Endcode_AES_ECB(strToEncode:String,key:String)->String {
        
        var encodeString = ""
        do{
            
            let aes = try AES(key: Padding.zeroPadding.add(to: key.bytes, blockSize: AES.blockSize),blockMode: ECB())
             //开始加密
            let encoded = try aes.encrypt(strToEncode.bytes)
            //将加密结果转成base64形式
            encodeString = encoded.toBase64()!
            print("加密结果：\(encodeString)")
        }catch{
            print(error.localizedDescription)
        }
        return encodeString
    }
    
    //decode
    public static func Decode_AES_ECB(strToDecode:String,key:String)->String {
        
        var decodeStr = ""
        let data = NSData(base64Encoded: strToDecode, options: NSData.Base64DecodingOptions.init(rawValue: 0))
        var encrypted: [UInt8] = []
        let count = data?.length
        for i in 0..<count! {
            var temp:UInt8 = 0
            data?.getBytes(&temp, range: NSRange(location: i,length:1 ))
            encrypted.append(temp)
        }
        do {
            let aes = try AES(key: Padding.zeroPadding.add(to: key.bytes, blockSize: AES.blockSize),blockMode: ECB())
              //开始解密1（从加密后的字符数组解密）
            let decode = try aes.decrypt(encrypted)
            //开始解密2（从加密后的base64字符串解密）
//              let decrypted2 = try encryptedBase64?.decryptBase64ToString(cipher: aes)
            let encoded = Data(decode)
            decodeStr = String(bytes: encoded.bytes, encoding: .utf8)!
            
        }catch{
            print(error.localizedDescription)
        }
        
        
        return decodeStr
    }
}
