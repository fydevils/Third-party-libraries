//
//  ViewController.swift
//  CryptoSwift_Demo
//
//  Created by 李娜 on 2019/2/28.
//  Copyright © 2019 李娜. All rights reserved.
//

import UIKit
import CryptoSwift

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        //在进行 AES 加密时，CryptoSwift 会根据密钥的长度自动选择对应的加密算法（AES128, AES192, AES256）
//        AES-128 = 16 bytes
//        AES-192 = 24 bytes
//        AES-256 = 32 bytes
        
        let CryptString:String = CryptTools.Endcode_AES_ECB(strToEncode: "加密信息", key: "密钥")
         print("加密结果：\(CryptString)")

        /*常用的数据类型转换*/
       // 使用字符串生成字节数组
        let bytes: Array<UInt8> = "password".bytes
        //字符串的base64编码
        let string = "hangge.com"
        let base64String2 = string.bytes.toBase64() //aGFuZ2dlLmNvbQ==
        print("加密结果：\(String(describing: base64String2))")
       
        
        
        /*计算 MD5 值*/
        /*** 计算字节数组的MD5值 ***/
        let bytes1:Array<UInt8> = [0x01, 0x02, 0x03]
        print("加密结果：\(bytes1)")
        //方式一
        let digest1 = bytes1.md5().toHexString() //5289df737df57326fcdd22597afb1fac
        print("加密结果：\(digest1)")
        //方式二
        let digest2 = Digest.md5(bytes1).toHexString() //5289df737df57326fcdd22597afb1fac
        
        /*** 计算Data的MD5值 ***/
        let data = Data(bytes: [0x01, 0x02, 0x03])
        let digest3 = data.md5().toHexString() //5289df737df57326fcdd22597afb1fac
        
        /*** 计算字符串的MD5值 ***/
        let digest4 = "hangge.com".md5() //7c19a729eb62e03fcf1a8b4abbf591ed
        
        
       
        
        
        
    
    }


}

